


function createNormalMember() {
	location.href = "NormalMemberCreateView.jsp";	   
}

function createEmployeeMember() {
	location.href = "EmployeeMemberCreateView.jsp";	   
}



function cancleBtn()
{
	history.go(-1);
}


function normalMemberUpdateBtn() {
	location.href = "NormalMemberUpdateView.jsp";
}

function memberDeleteBtn() {
	location.href = "MemberDeleteView.jsp";
}

function getMemberType() {
	location.href = "MemberTypeView.jsp";	   
}