package member;


public class MemberData {

	public String memberID;
	public String ID;
	public String password;
	public String name;
	public int genderStatus;
	public String truthResidence;
	public String homePhoneNo;
	public String phoneNo;
	public String emergencyContact ;
	public String email;
	public String address;
	
	public MemberData() {
		// TODO Auto-generated constructor stub
	}
	public String getMemberID() {
		return memberID;
	}
	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getGenderStatus() {
		return genderStatus;
	}
	public void setGenderStatus(int genderStatus) {
		this.genderStatus = genderStatus;
	}
	public String getTruthResidence() {
		return truthResidence;
	}
	public void setTruthResidence(String truthResidence) {
		this.truthResidence = truthResidence;
	}
	public String getHomePhoneNo() {
		return homePhoneNo;
	}
	public void setHomePhoneNo(String homePhoneNo) {
		this.homePhoneNo = homePhoneNo;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getEmergencyContact() {
		return emergencyContact;
	}
	public void setEmergencyContact(String emergencyContact) {
		this.emergencyContact = emergencyContact;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	

}

