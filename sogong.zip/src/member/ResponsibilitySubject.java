package member;

public class ResponsibilitySubject {

	public String responsibilitySubject;
	public String memberID;
	public String getResponsibilitySubject() {
		return responsibilitySubject;
	}
	public void setResponsibilitySubject(String responsibilitySubject) {
		this.responsibilitySubject = responsibilitySubject;
	}
	public String getMemberID() {
		return memberID;
	}
	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}
	
}
